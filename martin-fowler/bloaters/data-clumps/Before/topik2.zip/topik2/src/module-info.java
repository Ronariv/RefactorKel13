/**
 * 
 */
/**
 * @author raien
 *
 */
module topik2 {
}