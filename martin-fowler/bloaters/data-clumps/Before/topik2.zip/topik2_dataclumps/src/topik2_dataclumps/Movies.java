package topik2_dataclumps;

import java.util.Date;

public class Movies {
	private String movieName;
	public Movies(String movieName){
		super();
		this.movieName=movieName;
	}
	
	public String getName(){
		return movieName;
	}
	
}

