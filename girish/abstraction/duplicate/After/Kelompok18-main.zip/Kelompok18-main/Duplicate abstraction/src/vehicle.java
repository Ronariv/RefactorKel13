
abstract class vehicle{
	abstract void model();
	abstract void color();
	abstract void cylinderCapacity();
	public void stock() {
		System.out.println("available");
	}
}



class mercedes extends vehicle{
	public void model() {
		System.out.println("e320");
	}
	public void color() {
		System.out.println("silver");
	}
	public void cylinderCapacity(){
		System.out.println("4500cc");
	}
}

class ducati extends vehicle{
	public void model() {
		System.out.println("v4S");
	}
	public void color() {
		System.out.println("red");
	}
	public void cylinderCapacity() {
		System.out.println("1103cc");
	}
}