# soal-code-RE
Multifaceted Abstraction &amp; Unnecessary Abstraction
