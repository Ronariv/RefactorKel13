package girish.encapsulation.deficient.before;

public class SizeRequirement {
	//Do something
	
	/** The alignment, specified as a value between 0.0 and 1.0,
	inclusive. To specify centering, the alignment should be 0.5. */
	public float alignment;
	
	//Do something
}